a = int(input("Enter number a: "))
b = int(input("Enter number b: "))

try:
    print(a/b)
except:
    print("Infinite")