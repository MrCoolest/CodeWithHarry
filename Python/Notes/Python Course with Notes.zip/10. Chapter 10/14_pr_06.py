class Sample: 
    def __init__(slf, name):
        slf.name = name

obj = Sample("Harry") 
print(obj.name) 
 