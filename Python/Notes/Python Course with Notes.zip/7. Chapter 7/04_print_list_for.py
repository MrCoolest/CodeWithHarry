fruits = ['Banana', 'Watermelon', 'Grapes', 'Mangoes']

for item in fruits:
    print(item)
   
