a = [2, 4, 56, 7]

print(a[0] + a[1] + a[2] + a[3])
print(sum(a))