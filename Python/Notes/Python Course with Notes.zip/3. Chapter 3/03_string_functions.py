story = "once upon a time there was a youtuber named Harry who uploaded python course with notes Harry"

# String Functions
# print(len(story))
# print(story.endswith("notes"))
# print(story.count("c"))
# print(story.capitalize())
# print(story.find("upon"))
print(story.replace("Harry", "CodeWithHarry"))
 